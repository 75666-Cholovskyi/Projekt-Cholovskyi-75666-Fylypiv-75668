package Membership;

public class BasicMembership extends Membership {

    private static final String MEMBERSHIP_TYPE = "BASIC";

    public BasicMembership(double price, int durationDays) {
        super(price, durationDays);
    }

    public String getMembershipType() {
        return MEMBERSHIP_TYPE;
    }

    @Override
    public void displayMembership() {
        System.out.println("=== BASIC MEMBERSHIP ===");
        System.out.println(super.toString());
        System.out.println("Type: " + MEMBERSHIP_TYPE);
        System.out.println("Access: Basic gym equipment");
        System.out.println("Expired: " + isExpired());
    }

    @Override
    public String toString() {
        return MEMBERSHIP_TYPE + " " + super.toString();
    }
}