package Membership;

public class PremiumMembership extends Membership {

    private static final String MEMBERSHIP_TYPE = "PREMIUM";

    private final boolean swimmingPoolAccess;
    private final boolean saunaAccess;

    public PremiumMembership(double price, int durationDays) {
        super(price, durationDays);

        swimmingPoolAccess = true;
        saunaAccess = true;
    }

    public String getMembershipType() {
        return MEMBERSHIP_TYPE;
    }

    public boolean hasSwimmingPoolAccess() {
        return swimmingPoolAccess;
    }

    public boolean hasSaunaAccess() {
        return saunaAccess;
    }

    @Override
    public void displayMembership() {
        System.out.println("=== PREMIUM MEMBERSHIP ===");
        System.out.println(super.toString());
        System.out.println("Type: " + MEMBERSHIP_TYPE);
        System.out.println("Swimming pool: " + swimmingPoolAccess);
        System.out.println("Sauna: " + saunaAccess);
        System.out.println("Expired: " + isExpired());
    }

    @Override
    public String toString() {
        return MEMBERSHIP_TYPE + " " + super.toString();
    }
}