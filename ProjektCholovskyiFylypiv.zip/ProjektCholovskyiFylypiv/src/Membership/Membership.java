package Membership;

import Exceptions.InvalidMembershipException;
import Interfaces.Displayable;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Membership implements Comparable<Membership>, Displayable {

    private static int nextId = 201;
    private static int totalMemberships = 0;

    private final int membershipId;
    private final double price;
    private final int durationDays;
    private final LocalDate startDate;
    private final LocalDate expirationDate;

    public Membership(double price, int durationDays) {

        if (price <= 0) {
            throw new InvalidMembershipException("Price must be positive!");
        }

        if (durationDays <= 0) {
            throw new InvalidMembershipException("Duration must be positive!");
        }

        membershipId = nextId++;
        this.price = price;
        this.durationDays = durationDays;

        startDate = LocalDate.now();
        expirationDate = startDate.plusDays(durationDays);

        totalMemberships++;
    }

    public int getMembershipId() {
        return membershipId;
    }

    public double getPrice() {
        return price;
    }

    public int getDurationDays() {
        return durationDays;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public static int getTotalMemberships() {
        return totalMemberships;
    }

    public boolean isExpired() {
        return !LocalDate.now().isBefore(expirationDate);
    }

    public abstract void displayMembership();

    @Override
    public void displayInfo() {
        displayMembership();
    }

    @Override
    public int compareTo(Membership other) {
        return Double.compare(price, other.price);
    }

    @Override
    public String toString() {
        return "Membership ID: " + membershipId
                + ", Price: " + price
                + ", Duration: " + durationDays + " days"
                + ", Expiration: " + expirationDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Membership other = (Membership) obj;
        return membershipId == other.membershipId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getClass(), membershipId);
    }
}