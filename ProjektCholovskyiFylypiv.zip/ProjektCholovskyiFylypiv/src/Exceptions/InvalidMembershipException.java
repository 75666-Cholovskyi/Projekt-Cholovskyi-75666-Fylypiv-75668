package Exceptions;

public class InvalidMembershipException extends RuntimeException {

    public InvalidMembershipException(String message) {
        super(message);
    }
}