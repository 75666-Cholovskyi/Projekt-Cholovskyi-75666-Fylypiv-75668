package Workout;

import People.Client;
import People.Trainer;

public class PersonalWorkout extends Workout {

    private final String intensity;
    private final double caloriesPerMinute;

    public PersonalWorkout(Client client, Trainer trainer,
                           String workoutName, int durationMinutes,
                           String intensity) {

        super(client, trainer, workoutName, durationMinutes);

        if (intensity == null) {
            throw new IllegalArgumentException("Intensity is required!");
        }

        switch (intensity.trim().toUpperCase()) {
            case "LOW":
                caloriesPerMinute = 5.0;
                this.intensity = "LOW";
                break;

            case "MEDIUM":
                caloriesPerMinute = 8.0;
                this.intensity = "MEDIUM";
                break;

            case "HIGH":
                caloriesPerMinute = 12.0;
                this.intensity = "HIGH";
                break;

            default:
                throw new IllegalArgumentException(
                        "Intensity must be LOW, MEDIUM or HIGH!"
                );
        }
    }

    public String getIntensity() {
        return intensity;
    }

    @Override
    public double calculateCalories() {
        return getDurationMinutes() * caloriesPerMinute;
    }

    @Override
    public void displayWorkout() {
        System.out.println("=== PERSONAL WORKOUT ===");
        System.out.println(super.toString());
        System.out.println("Intensity: " + intensity);
        System.out.println("Estimated calories: " + calculateCalories());
    }

    @Override
    public String toString() {
        return "Personal " + super.toString()
                + ", Intensity: " + intensity
                + ", Calories: " + calculateCalories();
    }
}