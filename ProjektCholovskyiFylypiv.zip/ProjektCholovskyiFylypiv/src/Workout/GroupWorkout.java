package Workout;

import People.Client;
import People.Trainer;

public class GroupWorkout extends Workout {

    private final int participantsCount;
    private final String groupType;
    private final double caloriesPerMinute;

    public GroupWorkout(Client client, Trainer trainer,
                        String workoutName, int durationMinutes,
                        int participantsCount, String groupType) {

        super(client, trainer, workoutName, durationMinutes);

        if (participantsCount < 2 || participantsCount > 30) {
            throw new IllegalArgumentException(
                    "Participants must be between 2 and 30!"
            );
        }

        if (groupType == null) {
            throw new IllegalArgumentException("Group type is required!");
        }

        this.participantsCount = participantsCount;

        switch (groupType.trim().toUpperCase()) {
            case "YOGA":
                caloriesPerMinute = 4.0;
                this.groupType = "YOGA";
                break;

            case "FITNESS":
                caloriesPerMinute = 7.0;
                this.groupType = "FITNESS";
                break;

            case "CROSSFIT":
                caloriesPerMinute = 11.0;
                this.groupType = "CROSSFIT";
                break;

            default:
                throw new IllegalArgumentException(
                        "Group type must be YOGA, FITNESS or CROSSFIT!"
                );
        }
    }

    public int getParticipantsCount() {
        return participantsCount;
    }

    public String getGroupType() {
        return groupType;
    }

    @Override
    public double calculateCalories() {
        return getDurationMinutes() * caloriesPerMinute;
    }

    @Override
    public void displayWorkout() {
        System.out.println("=== GROUP WORKOUT ===");
        System.out.println(super.toString());
        System.out.println("Group type: " + groupType);
        System.out.println("Participants: " + participantsCount);
        System.out.println("Estimated calories per participant: "
                + calculateCalories());
    }

    @Override
    public String toString() {
        return "Group " + super.toString()
                + ", Type: " + groupType
                + ", Participants: " + participantsCount
                + ", Calories per participant: " + calculateCalories();
    }
}