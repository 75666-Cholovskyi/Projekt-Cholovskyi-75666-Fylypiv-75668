package Workout;

import People.Client;
import People.Trainer;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Workout {

    private static int nextId = 401;
    private static int totalWorkouts = 0;

    private final int workoutId;
    private final Client client;
    private final Trainer trainer;
    private final String workoutName;
    private final LocalDate workoutDate;
    private final int durationMinutes;

    public Workout(Client client, Trainer trainer,
                   String workoutName, int durationMinutes) {

        if (client == null || trainer == null) {
            throw new IllegalArgumentException(
                    "Client and trainer are required!"
            );
        }

        if (workoutName == null || workoutName.trim().isEmpty()) {
            throw new IllegalArgumentException("Workout name cannot be empty!");
        }

        if (durationMinutes <= 0) {
            throw new IllegalArgumentException("Duration must be positive!");
        }

        workoutId = nextId++;
        this.client = client;
        this.trainer = trainer;
        this.workoutName = workoutName.trim();
        this.durationMinutes = durationMinutes;
        workoutDate = LocalDate.now();

        totalWorkouts++;
    }

    public int getWorkoutId() {
        return workoutId;
    }

    public Client getClient() {
        return client;
    }

    public Trainer getTrainer() {
        return trainer;
    }

    public String getWorkoutName() {
        return workoutName;
    }

    public LocalDate getWorkoutDate() {
        return workoutDate;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public static int getTotalWorkouts() {
        return totalWorkouts;
    }

    public abstract void displayWorkout();

    public abstract double calculateCalories();

    @Override
    public String toString() {
        return "Workout ID: " + workoutId
                + ", Name: " + workoutName
                + ", Client: " + client.getName()
                + ", Trainer: " + trainer.getName()
                + ", Date: " + workoutDate
                + ", Duration: " + durationMinutes + " minutes";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Workout other = (Workout) obj;
        return workoutId == other.workoutId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getClass(), workoutId);
    }
}