import People.Client;
import People.Trainer;
import People.Admin;

import Membership.Membership;
import Membership.BasicMembership;
import Membership.PremiumMembership;

import Payment.Payment;
import Payment.PaymentMethod;

import Workout.Workout;
import Workout.PersonalWorkout;
import Workout.GroupWorkout;

import Services.GymService;
import Services.InputService;

import Interfaces.UserInterface;
import Interfaces.ConsoleUserInterface;

import java.util.Scanner;

public class Main {

    private static GymService gym = new GymService();
    private static InputService input;
    private static UserInterface userInterface = new ConsoleUserInterface();

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        input = new InputService(scanner);

        loadDemoData();

        boolean running = true;

        while (running) {

            clearScreen();

            System.out.println("=================================");
            System.out.println("     GYM MANAGEMENT SYSTEM");
            System.out.println("=================================");

            userInterface.displayMenu();

            int choice = input.readInt("Choose option: ");

            if (choice == 0) {

                clearScreen();

                System.out.println("=================================");
                System.out.println("Thank you for using Gym Management System!");
                System.out.println("Goodbye!");
                System.out.println("=================================");

                running = false;
                continue;
            }

            clearScreen();

            try {

                switch (choice) {

                    case 1:
                        showClients();
                        break;

                    case 2:
                        addClient();
                        break;

                    case 3:
                        searchClient();
                        break;

                    case 4:
                        removeClient();
                        break;

                    case 5:
                        showTrainers();
                        break;

                    case 6:
                        addTrainer();
                        break;

                    case 7:
                        showAdmins();
                        break;

                    case 8:
                        showMemberships();
                        break;

                    case 9:
                        createMembership();
                        break;

                    case 10:
                        createPayment();
                        break;

                    case 11:
                        completePayment();
                        break;

                    case 12:
                        showPayments();
                        break;

                    case 13:
                        createWorkout();
                        break;

                    case 14:
                        showWorkouts();
                        break;

                    case 15:
                        sortClients();
                        break;

                    case 16:
                        sortMemberships();
                        break;

                    case 17:
                        showFinancialStatistics();
                        break;

                    case 18:
                        showGeneralStatistics();
                        break;

                    default:
                        System.out.println("Invalid menu option!");
                }

            } catch (RuntimeException e) {

                System.out.println("\nERROR: " + e.getMessage());

            }

            input.waitForEnter();
        }

        scanner.close();
    }

    private static void clearScreen() {

        for (int i = 0; i < 50; i++) {
            System.out.println();
        }
    }

    private static void showClients() {

        System.out.println("\n=== CLIENTS ===");
        gym.displayAll(gym.getClients());
    }

    private static void addClient() {

        System.out.println("\n=== REGISTER CLIENT ===");

        String name = input.readString("Name: ");
        int age = input.readInt("Age: ");
        String email = input.readString("Email: ");

        Client client = new Client(name, age, email);

        gym.addClient(client);

        System.out.println("Client registered successfully!");
        System.out.println("Generated ID: " + client.getClientId());
    }

    private static void searchClient() {

        int id = input.readInt("Enter client ID: ");

        Client client = gym.findById(id);

        if (client == null) {
            System.out.println("Client not found.");
        } else {
            client.displayInfo();
        }
    }

    private static void removeClient() {

        int id = input.readInt("Enter client ID to remove: ");

        boolean removed = gym.removeClient(id);

        if (removed) {
            System.out.println("Client removed successfully!");
        } else {
            System.out.println("Client not found.");
        }
    }

    private static void showTrainers() {

        System.out.println("\n=== TRAINERS ===");
        gym.displayAll(gym.getTrainers());
    }

    private static void addTrainer() {

        System.out.println("\n=== ADD TRAINER ===");

        String name = input.readString("Name: ");
        int age = input.readInt("Age: ");
        String email = input.readString("Email: ");
        String specialization = input.readString("Specialization: ");
        double salary = input.readDouble("Salary: ");

        Trainer trainer = new Trainer(
                name, age, email, specialization, salary
        );

        gym.addTrainer(trainer);

        System.out.println("Trainer added!");
        System.out.println("Generated ID: " + trainer.getTrainerId());
    }

    private static void showAdmins() {

        System.out.println("\n=== ADMINS ===");
        gym.displayAll(gym.getAdmins());
    }

    private static void showMemberships() {

        System.out.println("\n=== MEMBERSHIPS ===");
        gym.displayAll(gym.getMemberships());
    }

    private static void createMembership() {

        System.out.println("\n=== CREATE MEMBERSHIP ===");

        int clientId = input.readInt("Client ID: ");
        Client client = gym.findById(clientId);

        if (client == null) {
            System.out.println("Client not found!");
            return;
        }

        System.out.println("1. Basic Membership");
        System.out.println("2. Premium Membership");

        int type = input.readInt("Choose membership: ");

        if (type != 1 && type != 2) {
            System.out.println("Invalid membership type!");
            return;
        }

        double price = input.readDouble("Price: ");
        int duration = input.readInt("Duration in days: ");

        Membership membership;

        if (type == 1) {
            membership = new BasicMembership(price, duration);
        } else {
            membership = new PremiumMembership(price, duration);
        }

        gym.addMembership(membership);
        client.assignMembership(membership);

        System.out.println("Membership assigned successfully!");
        System.out.println("Membership ID: " + membership.getMembershipId());
    }

    private static void createPayment() {

        System.out.println("\n=== CREATE PAYMENT ===");

        int clientId = input.readInt("Client ID: ");
        Client client = gym.findById(clientId);

        if (client == null) {
            System.out.println("Client not found!");
            return;
        }

        double amount = input.readDouble("Amount: ");

        System.out.println("Payment methods:");

        PaymentMethod[] methods = PaymentMethod.values();

        for (int i = 0; i < methods.length; i++) {
            System.out.println((i + 1) + ". " + methods[i]);
        }

        int methodChoice = input.readInt("Choose method: ");

        if (methodChoice < 1 || methodChoice > methods.length) {
            System.out.println("Invalid payment method!");
            return;
        }

        Payment payment = new Payment(
                client,
                amount,
                methods[methodChoice - 1]
        );

        gym.addPayment(payment);

        System.out.println("Payment created!");
        System.out.println("Payment ID: " + payment.getPaymentId());
        System.out.println("Status: Unpaid");
    }

    private static void completePayment() {

        System.out.println("\n=== COMPLETE PAYMENT ===");

        int id = input.readInt("Enter payment ID: ");
        Payment payment = gym.findPaymentById(id);

        if (payment == null) {
            System.out.println("Payment not found!");
            return;
        }

        payment.completePayment();

        System.out.println("Payment completed successfully!");
    }

    private static void showPayments() {

        System.out.println("\n=== PAYMENTS ===");
        gym.displayAll(gym.getPayments());
    }

    private static void createWorkout() {

        System.out.println("\n=== CREATE WORKOUT ===");

        int clientId = input.readInt("Client ID: ");
        Client client = gym.findById(clientId);

        if (client == null) {
            System.out.println("Client not found!");
            return;
        }

        int trainerId = input.readInt("Trainer ID: ");
        Trainer trainer = gym.findTrainerById(trainerId);

        if (trainer == null) {
            System.out.println("Trainer not found!");
            return;
        }

        String name = input.readString("Workout name: ");
        int duration = input.readInt("Duration in minutes: ");

        System.out.println("1. Personal Workout");
        System.out.println("2. Group Workout");

        int type = input.readInt("Choose type: ");

        Workout workout;

        if (type == 1) {

            String[] levels = {"LOW", "MEDIUM", "HIGH"};

            System.out.println("\nAvailable intensity levels:");

            for (int i = 0; i < levels.length; i++) {
                System.out.println((i + 1) + ". " + levels[i]);
            }

            String intensity = input.readString(
                    "Intensity (LOW / MEDIUM / HIGH): "
            );

            workout = new PersonalWorkout(
                    client, trainer, name, duration, intensity
            );

        } else if (type == 2) {

            int participants = input.readInt("Participants count: ");

            String groupType = input.readString(
                    "Group type (YOGA / FITNESS / CROSSFIT): "
            );

            workout = new GroupWorkout(
                    client, trainer, name, duration,
                    participants, groupType
            );

        } else {

            System.out.println("Invalid workout type!");
            return;
        }

        gym.addWorkout(workout);

        System.out.println("Workout created successfully!");
        System.out.println("Workout ID: " + workout.getWorkoutId());
        System.out.println("Estimated calories: "
                + workout.calculateCalories());
    }

    private static void showWorkouts() {

        System.out.println("\n=== WORKOUTS ===");
        gym.displayAll(gym.getWorkouts());
    }

    private static void sortClients() {

        System.out.println("\n=== SORT CLIENTS ===");
        System.out.println("1. Sort by name");
        System.out.println("2. Sort by age");

        int choice = input.readInt("Choose sorting method: ");

        if (choice == 1) {
            gym.sortClientsByName();

        } else if (choice == 2) {
            gym.sortClientsByAge();

        } else {
            System.out.println("Invalid option!");
            return;
        }

        showClients();
    }

    private static void sortMemberships() {

        System.out.println("\n=== SORT MEMBERSHIPS ===");
        System.out.println("1. Sort by price (Comparable)");
        System.out.println("2. Sort by duration (Comparator)");

        int choice = input.readInt("Choose sorting method: ");

        if (choice == 1) {

            gym.sortMembershipsByPrice();
            System.out.println("\nMemberships sorted by price:");

        } else if (choice == 2) {

            gym.sortMembershipsByDuration();
            System.out.println("\nMemberships sorted by duration:");

        } else {

            System.out.println("Invalid option!");
            return;
        }

        showMemberships();
    }

    private static void showFinancialStatistics() {

        System.out.println("\n=== FINANCIAL STATISTICS ===");

        System.out.println("Total revenue: "
                + gym.getTotalRevenue() + " PLN");

        System.out.println("Unpaid amount: "
                + gym.getUnpaidAmount() + " PLN");

        System.out.println("Number of payments: "
                + gym.getPaymentCount());
    }

    private static void showGeneralStatistics() {

        System.out.println("\n=== GENERAL STATISTICS ===");

        System.out.println("Clients: " + gym.getClientCount());
        System.out.println("Trainers: " + gym.getTrainerCount());
        System.out.println("Admins: " + gym.getAdminCount());
        System.out.println("Memberships: " + gym.getMembershipCount());
        System.out.println("Payments: " + gym.getPaymentCount());
        System.out.println("Workouts: " + gym.getWorkoutCount());
    }

    private static void loadDemoData() {

        Client client1 = new Client(
                "Vlad", 18, "vlad@gmail.com"
        );

        Client client2 = new Client(
                "Denis", 21, "denis@gmail.com"
        );

        Trainer trainer1 = new Trainer(
                "Alex", 28, "alex@gmail.com",
                "Bodybuilding", 5000
        );

        Trainer trainer2 = new Trainer(
                "Mark", 30, "mark@gmail.com",
                "Fitness", 4500
        );

        Admin admin1 = new Admin(
                "John", 35, "john@gmail.com",
                "Manager", 5
        );

        Admin admin2 = new Admin(
                "Anna", 29, "anna@gmail.com",
                "Receptionist", 2
        );

        Membership basic1 = new BasicMembership(100, 30);
        Membership basic2 = new BasicMembership(250, 90);

        Membership premium1 = new PremiumMembership(200, 30);
        Membership premium2 = new PremiumMembership(500, 90);

        client1.assignMembership(basic1);
        client2.assignMembership(premium1);

        gym.addClient(client1);
        gym.addClient(client2);

        gym.addTrainer(trainer1);
        gym.addTrainer(trainer2);

        gym.addAdmin(admin1);
        gym.addAdmin(admin2);

        gym.addMembership(basic1);
        gym.addMembership(basic2);
        gym.addMembership(premium1);
        gym.addMembership(premium2);

        Payment payment1 = new Payment(
                client1, 100, PaymentMethod.CARD
        );

        Payment payment2 = new Payment(
                client2, 200, PaymentMethod.BLIK
        );

        payment1.completePayment();

        gym.addPayment(payment1);
        gym.addPayment(payment2);

        Workout workout1 = new PersonalWorkout(
                client1, trainer1,
                "Strength Training", 60, "HIGH"
        );

        Workout workout2 = new GroupWorkout(
                client2, trainer2,
                "Morning Yoga", 45, 10, "YOGA"
        );

        Workout workout3 = new PersonalWorkout(
                client2, trainer1,
                "Cardio Training", 40, "MEDIUM"
        );

        Workout workout4 = new GroupWorkout(
                client1, trainer2,
                "Crossfit Training", 50, 8, "CROSSFIT"
        );

        gym.addWorkout(workout1);
        gym.addWorkout(workout2);
        gym.addWorkout(workout3);
        gym.addWorkout(workout4);
    }
}