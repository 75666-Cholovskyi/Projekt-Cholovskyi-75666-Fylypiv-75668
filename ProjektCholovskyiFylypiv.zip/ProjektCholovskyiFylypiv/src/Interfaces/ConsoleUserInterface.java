package Interfaces;

import Interfaces.UserInterface;

public class ConsoleUserInterface implements UserInterface {

    @Override
    public void displayMenu() {

        System.out.println("\n========== MAIN MENU ==========");

        System.out.println("1.  Show clients");
        System.out.println("2.  Register client");
        System.out.println("3.  Search client");
        System.out.println("4.  Remove client");

        System.out.println("5.  Show trainers");
        System.out.println("6.  Add trainer");
        System.out.println("7.  Show admins");

        System.out.println("8.  Show memberships");
        System.out.println("9.  Create and assign membership");

        System.out.println("10. Create payment");
        System.out.println("11. Complete payment");
        System.out.println("12. Show payments");

        System.out.println("13. Create workout");
        System.out.println("14. Show workouts");

        System.out.println("15. Sort clients");
        System.out.println("16. Sort memberships");

        System.out.println("17. Financial statistics");
        System.out.println("18. General statistics");

        System.out.println("0.  Exit");

        System.out.println("===============================");
    }
}