package Interfaces;

public interface UserInterface {

    void displayMenu();

}