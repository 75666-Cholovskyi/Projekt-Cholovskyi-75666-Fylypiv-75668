package Interfaces;

public interface Searchable<T> {
    T findById(int id);

    boolean exists(int id);
}