package Services;

import java.util.Scanner;

public class InputService {

    private final Scanner scanner;

    public InputService(Scanner scanner) {
        if (scanner == null) {
            throw new IllegalArgumentException("Scanner cannot be null!");
        }

        this.scanner = scanner;
    }

    public String readString(String message) {
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine().trim();

            if (!input.isEmpty()) {
                return input;
            }

            System.out.println("Input cannot be empty!");
        }
    }

    public int readInt(String message) {
        while (true) {
            System.out.print(message);

            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer!");
            }
        }
    }

    public double readDouble(String message) {
        while (true) {
            System.out.print(message);

            try {
                String value = scanner.nextLine().trim().replace(',', '.');
                double number = Double.parseDouble(value);

                if (Double.isFinite(number)) {
                    return number;
                }

                System.out.println("Number must be finite!");

            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number!");
            }
        }
    }

    public boolean readBoolean(String message) {
        while (true) {
            String value = readString(message + " (yes/no): ");

            if (value.equalsIgnoreCase("yes")
                    || value.equalsIgnoreCase("y")) {
                return true;
            }

            if (value.equalsIgnoreCase("no")
                    || value.equalsIgnoreCase("n")) {
                return false;
            }

            System.out.println("Enter yes or no!");
        }
    }

    public void waitForEnter() {
        System.out.println();
        System.out.print("Press ENTER to return to the main menu...");
        scanner.nextLine();
    }
}