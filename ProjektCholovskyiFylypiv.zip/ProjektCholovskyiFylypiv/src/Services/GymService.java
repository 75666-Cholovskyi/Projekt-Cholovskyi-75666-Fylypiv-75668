package Services;

import People.Client;
import People.Trainer;
import People.Admin;

import Membership.Membership;

import Payment.Payment;

import Workout.Workout;

import Interfaces.Searchable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class GymService implements Searchable<Client> {

    private final List<Client> clients = new ArrayList<>();
    private final List<Trainer> trainers = new ArrayList<>();
    private final List<Admin> admins = new ArrayList<>();
    private final List<Membership> memberships = new ArrayList<>();
    private final List<Payment> payments = new ArrayList<>();
    private final List<Workout> workouts = new ArrayList<>();

    public void addClient(Client client) {
        if (client == null || exists(client.getClientId())) {
            throw new IllegalArgumentException("Invalid or duplicate client!");
        }

        clients.add(client);
    }

    @Override
    public Client findById(int id) {
        for (Client client : clients) {
            if (client.getClientId() == id) {
                return client;
            }
        }

        return null;
    }

    @Override
    public boolean exists(int id) {
        return findById(id) != null;
    }

    public boolean removeClient(int id) {
        Client client = findById(id);

        if (client == null) {
            return false;
        }

        boolean hasPayment = payments.stream()
                .anyMatch(p -> p.getClient().getClientId() == id);

        boolean hasWorkout = workouts.stream()
                .anyMatch(w -> w.getClient().getClientId() == id);

        if (hasPayment || hasWorkout) {
            throw new IllegalStateException(
                    "Cannot remove client with payment or workout history!"
            );
        }

        clients.remove(client);
        return true;
    }

    public List<Client> getClients() {
        return new ArrayList<>(clients);
    }

    public void sortClientsByName() {
        clients.sort(Comparator.comparing(Client::getName));
    }

    public void sortClientsByAge() {
        clients.sort(Comparator.comparingInt(Client::getAge));
    }


    public void addTrainer(Trainer trainer) {
        if (trainer == null || findTrainerById(trainer.getTrainerId()) != null) {
            throw new IllegalArgumentException("Invalid or duplicate trainer!");
        }

        trainers.add(trainer);
    }

    public Trainer findTrainerById(int id) {
        for (Trainer trainer : trainers) {
            if (trainer.getTrainerId() == id) {
                return trainer;
            }
        }

        return null;
    }

    public boolean removeTrainer(int id) {
        Trainer trainer = findTrainerById(id);

        if (trainer == null) {
            return false;
        }

        boolean hasWorkout = workouts.stream()
                .anyMatch(w -> w.getTrainer().getTrainerId() == id);

        if (hasWorkout) {
            throw new IllegalStateException(
                    "Cannot remove trainer with workout history!"
            );
        }

        trainers.remove(trainer);
        return true;
    }

    public List<Trainer> getTrainers() {
        return new ArrayList<>(trainers);
    }

    public void sortTrainersBySalary() {
        trainers.sort(Comparator.comparingDouble(Trainer::getSalary));
    }

    public void addAdmin(Admin admin) {
        if (admin == null) {
            throw new IllegalArgumentException("Admin cannot be null!");
        }

        admins.add(admin);
    }

    public List<Admin> getAdmins() {
        return new ArrayList<>(admins);
    }

    public void addMembership(Membership membership) {
        if (membership == null) {
            throw new IllegalArgumentException("Membership cannot be null!");
        }

        memberships.add(membership);
    }

    public List<Membership> getMemberships() {
        return new ArrayList<>(memberships);
    }

    public void sortMembershipsByPrice() {
        memberships.sort(Comparator.naturalOrder());
    }

    public void sortMembershipsByDuration() {
        memberships.sort(Comparator.comparingInt(Membership::getDurationDays));
    }

    public Membership findMembershipById(int id) {
        for (Membership membership : memberships) {
            if (membership.getMembershipId() == id) {
                return membership;
            }
        }

        return null;
    }

    public void addPayment(Payment payment) {
        if (payment == null) {
            throw new IllegalArgumentException("Payment cannot be null!");
        }

        payments.add(payment);
    }

    public List<Payment> getPayments() {
        return new ArrayList<>(payments);
    }

    public Payment findPaymentById(int id) {
        for (Payment payment : payments) {
            if (payment.getPaymentId() == id) {
                return payment;
            }
        }

        return null;
    }

    public double getTotalRevenue() {
        double total = 0;

        for (Payment payment : payments) {
            if (payment.isPaid()) {
                total += payment.getAmount();
            }
        }

        return total;
    }

    public double getUnpaidAmount() {
        double total = 0;

        for (Payment payment : payments) {
            if (!payment.isPaid()) {
                total += payment.getAmount();
            }
        }

        return total;
    }

    public void addWorkout(Workout workout) {
        if (workout == null) {
            throw new IllegalArgumentException("Workout cannot be null!");
        }

        workouts.add(workout);
    }

    public List<Workout> getWorkouts() {
        return new ArrayList<>(workouts);
    }

    public int getClientCount() {
        return clients.size();
    }

    public int getTrainerCount() {
        return trainers.size();
    }

    public int getAdminCount() {
        return admins.size();
    }

    public int getMembershipCount() {
        return memberships.size();
    }

    public int getPaymentCount() {
        return payments.size();
    }

    public int getWorkoutCount() {
        return workouts.size();
    }

    public <T> void displayAll(List<T> items) {
        if (items.isEmpty()) {
            System.out.println("No records found.");
            return;
        }

        for (T item : items) {
            System.out.println(item);
        }
    }
}