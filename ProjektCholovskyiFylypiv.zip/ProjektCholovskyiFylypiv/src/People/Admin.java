package People;

public class Admin extends Person {

    private static int nextId = 901;
    private static int totalAdmins = 0;

    private final int adminId;
    private String adminRole;
    private int accessLevel;
    private boolean active;

    public Admin(String name, int age, String email,
                 String adminRole, int accessLevel) {

        super(name, age, email);

        setAdminRole(adminRole);
        setAccessLevel(accessLevel);

        adminId = nextId++;
        active = true;
        totalAdmins++;
    }

    public int getAdminId() {
        return adminId;
    }

    public String getAdminRole() {
        return adminRole;
    }

    public int getAccessLevel() {
        return accessLevel;
    }

    public boolean isActive() {
        return active;
    }

    public static int getTotalAdmins() {
        return totalAdmins;
    }

    public void setAdminRole(String adminRole) {
        if (adminRole == null || adminRole.trim().isEmpty()) {
            throw new IllegalArgumentException("Role cannot be empty!");
        }

        this.adminRole = adminRole.trim();
    }

    public void setAccessLevel(int accessLevel) {
        if (accessLevel < 1 || accessLevel > 5) {
            throw new IllegalArgumentException("Access level must be 1-5!");
        }

        this.accessLevel = accessLevel;
    }

    public void activate() {
        active = true;
    }

    public void deactivate() {
        active = false;
    }

    @Override
    public void displayInfo() {
        System.out.println("=== ADMIN ===");
        System.out.println("ID: " + adminId);
        System.out.println(super.toString());
        System.out.println("Role: " + adminRole);
        System.out.println("Access level: " + accessLevel);
        System.out.println("Active: " + active);
    }

    @Override
    public String toString() {
        return "Admin ID: " + adminId + ", " + super.toString()
                + ", Role: " + adminRole
                + ", Access level: " + accessLevel
                + ", Active: " + active;
    }
}