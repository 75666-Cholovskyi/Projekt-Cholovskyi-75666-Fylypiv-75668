package People;

import Interfaces.Displayable;
import java.util.Objects;

public abstract class Person implements Displayable {

    private String name;
    private int age;
    private String email;

    public Person(String name, int age, String email) {
        setName(name);
        setAge(age);
        setEmail(email);
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty!");
        }

        this.name = name.trim();
    }

    public void setAge(int age) {
        if (age <= 0 || age > 120) {
            throw new IllegalArgumentException("Invalid age!");
        }

        this.age = age;
    }

    public void setEmail(String email) {
        if (email == null || !email.trim().contains("@")) {
            throw new IllegalArgumentException("Invalid email!");
        }

        this.email = email.trim();
    }

    @Override
    public abstract void displayInfo();

    @Override
    public String toString() {
        return "Name: " + name
                + ", Age: " + age
                + ", Email: " + email;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Person person = (Person) obj;
        return Objects.equals(email, person.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getClass(), email);
    }
}