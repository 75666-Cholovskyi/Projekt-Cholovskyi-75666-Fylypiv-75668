package People;

public class Trainer extends Person {

    private static int nextId = 501;
    private static int totalTrainers = 0;

    private final int trainerId;
    private String specialization;
    private double salary;
    private boolean active;

    public Trainer(String name, int age, String email,
                   String specialization, double salary) {

        super(name, age, email);

        setSpecialization(specialization);
        setSalary(salary);

        trainerId = nextId++;
        active = true;
        totalTrainers++;
    }

    public int getTrainerId() {
        return trainerId;
    }

    public String getSpecialization() {
        return specialization;
    }

    public double getSalary() {
        return salary;
    }

    public boolean isActive() {
        return active;
    }

    public static int getTotalTrainers() {
        return totalTrainers;
    }

    public void setSpecialization(String specialization) {
        if (specialization == null || specialization.trim().isEmpty()) {
            throw new IllegalArgumentException("Specialization cannot be empty!");
        }

        this.specialization = specialization.trim();
    }

    public void setSalary(double salary) {
        if (salary < 0) {
            throw new IllegalArgumentException("Salary cannot be negative!");
        }

        this.salary = salary;
    }

    public void activate() {
        active = true;
    }

    public void deactivate() {
        active = false;
    }

    @Override
    public void displayInfo() {
        System.out.println("=== TRAINER ===");
        System.out.println("ID: " + trainerId);
        System.out.println(super.toString());
        System.out.println("Specialization: " + specialization);
        System.out.println("Salary: " + salary + " PLN");
        System.out.println("Active: " + active);
    }

    @Override
    public String toString() {
        return "Trainer ID: " + trainerId + ", " + super.toString()
                + ", Specialization: " + specialization
                + ", Salary: " + salary
                + ", Active: " + active;
    }
}