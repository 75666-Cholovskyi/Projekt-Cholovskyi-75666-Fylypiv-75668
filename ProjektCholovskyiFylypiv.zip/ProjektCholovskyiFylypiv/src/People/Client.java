package People;

import Membership.Membership;

public class Client extends Person {

    private static int nextId = 101;
    private static int totalClients = 0;

    private final int clientId;
    private Membership membership;
    private boolean active;

    public Client(String name, int age, String email) {
        super(name, age, email);

        clientId = nextId++;
        active = true;
        totalClients++;
    }

    public int getClientId() {
        return clientId;
    }

    public Membership getMembership() {
        return membership;
    }

    public boolean isActive() {
        return active;
    }

    public static int getTotalClients() {
        return totalClients;
    }

    public void assignMembership(Membership membership) {
        if (membership == null) {
            throw new IllegalArgumentException("Membership cannot be null!");
        }

        this.membership = membership;
    }

    public void removeMembership() {
        membership = null;
    }

    public void deactivate() {
        active = false;
    }

    public void activate() {
        active = true;
    }

    @Override
    public void displayInfo() {
        System.out.println("=== CLIENT ===");
        System.out.println("ID: " + clientId);
        System.out.println(super.toString());
        System.out.println("Active: " + active);

        if (membership != null) {
            System.out.println("Membership: " + membership);
        } else {
            System.out.println("Membership: None");
        }
    }

    @Override
    public String toString() {
        return "Client ID: " + clientId + ", " + super.toString()
                + ", Active: " + active;
    }
}