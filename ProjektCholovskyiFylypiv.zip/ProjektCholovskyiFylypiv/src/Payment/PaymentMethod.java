package Payment;

public enum PaymentMethod {

    CASH("Cash"),
    CARD("Credit/Debit Card"),
    BANK_TRANSFER("Bank Transfer"),
    BLIK("BLIK");

    private final String description;

    PaymentMethod(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return description;
    }
}