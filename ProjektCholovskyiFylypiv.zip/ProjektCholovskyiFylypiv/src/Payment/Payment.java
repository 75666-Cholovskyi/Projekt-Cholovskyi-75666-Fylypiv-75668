package Payment;

import Exceptions.InvalidPaymentException;
import People.Client;

import java.time.LocalDate;
import java.util.Objects;

public class Payment {

    private static int nextId = 301;
    private static int totalPayments = 0;

    private final int paymentId;
    private final Client client;
    private final double amount;
    private final LocalDate paymentDate;
    private final PaymentMethod paymentMethod;

    private boolean paid;

    public Payment(Client client, double amount,
                   PaymentMethod paymentMethod) {

        if (client == null) {
            throw new InvalidPaymentException("Client cannot be null!");
        }

        if (amount <= 0) {
            throw new InvalidPaymentException("Amount must be positive!");
        }

        if (paymentMethod == null) {
            throw new InvalidPaymentException("Payment method cannot be null!");
        }

        paymentId = nextId++;
        this.client = client;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        paymentDate = LocalDate.now();
        paid = false;

        totalPayments++;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public Client getClient() {
        return client;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public boolean isPaid() {
        return paid;
    }

    public static int getTotalPayments() {
        return totalPayments;
    }

    public void completePayment() {
        paid = true;
    }

    public void refundPayment() {
        if (!paid) {
            throw new InvalidPaymentException(
                    "Cannot refund an unpaid payment!"
            );
        }

        paid = false;
    }

    public void displayPayment() {
        System.out.println("=== PAYMENT ===");
        System.out.println("ID: " + paymentId);
        System.out.println("Client: " + client.getName());
        System.out.println("Amount: " + amount + " PLN");
        System.out.println("Date: " + paymentDate);
        System.out.println("Method: " + paymentMethod);
        System.out.println("Paid: " + paid);
    }

    @Override
    public String toString() {
        return "Payment ID: " + paymentId
                + ", Client: " + client.getName()
                + ", Amount: " + amount + " PLN"
                + ", Date: " + paymentDate
                + ", Method: " + paymentMethod
                + ", Paid: " + paid;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Payment other = (Payment) obj;
        return paymentId == other.paymentId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(paymentId);
    }
}